#En este segundo ejercicio, tendréis que crear una interfaz sencilla 
#la cual debe de contener una lista de elementos seleccionables, 
#también debe de tener un label con el texto que queráis.

import tkinter

win = tkinter.Tk()


win.columnconfigure(0, weight=1)
win.columnconfigure(1, weight=3)


label = tkinter.Label(win, text='Etiqueta chida', bg='blue', fg='white')
label.grid(column=0,row=1)

lista = ['Mexico','Peru','Colombia']
seleccionado = tkinter.StringVar(value=lista)


listbox = tkinter.Listbox(win,height=0,listvariable=seleccionado)
listbox.grid(column=0,row=0)


win.mainloop()