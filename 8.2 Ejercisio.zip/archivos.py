import pickle

class Vehiculo:
	marca = ""
	modelo = ""

	def __init__(self,marca,modelo):
		self.marca = marca
		self.modelo = modelo

	def getMarca(self):
		return self.marca

ejercisio = Vehiculo("Nissan","Versa")

f = open('datos.bin', 'wb')
pickle.dump(ejercisio, f)
f.close()

f = open('datos.bin','rb')
res = pickle.load(f)
f.close()


print(res.getMarca())