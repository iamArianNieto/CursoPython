import operaciones

def main():
	resuma = operaciones.suma(2,2)
	print("Suma de 2+2=",resuma)

	resta = operaciones.resta(5,2)
	print("Resta de 5-2=",resta)

	mul = operaciones.multiplicar(2,2)
	print("Suma de 2*2=",mul)

	div = operaciones.dividir(10,2)
	print("Divicion de 10/2=",div)


if __name__ == '__main__':
    main()


		

