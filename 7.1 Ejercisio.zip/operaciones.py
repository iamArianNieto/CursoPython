def suma(a,b):
	return a + b

def resta(a,b):
	return a - b

def multiplicar(a,b):
	return a * b

def dividir(a,b):
	return a / b




		

