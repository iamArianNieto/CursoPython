#En este ejercicio tenéis que crear una lista de RadioButton que muestre la opción 
#que se ha seleccionado y que contenga un botón de reinicio para que deje todo como 
#al principio.
#Al principio no tiene que haber una opción seleccionada.

import tkinter

win = tkinter.Tk()


win.columnconfigure(0, weight=1)
win.columnconfigure(1, weight=3)

seleccionado = tkinter.StringVar()
r1 = tkinter.Radiobutton(win,text='Yes',value='1',variable=seleccionado)
r2 = tkinter.Radiobutton(win,text='No',value='2',variable=seleccionado)
r3 = tkinter.Radiobutton(win,text='quiza',value='3',variable=seleccionado)

r1.grid(column=0, row=1)
r2.grid(column=0, row=2)
r3.grid(column=0, row=3)

lista = [r1.select(),r2.deselect(),r3.deselect()]

listbox = tkinter.Listbox(win,height=0,listvariable=lista)
listbox.grid(column=0,row=0)

def limpiar(event):
	r1.select()
	r2.deselect()
	r3.deselect()

btn = tkinter.Button(win,text='Recetear')
btn.grid(column=0, row=4)
btn.bind('<Button-1>',limpiar)

win.mainloop()