
paises = []
c = 1
c= int(c)
while c < 6: 
    paises.append(input("Introduce un pais\n").upper())
    c += 1

se = set(paises)
print(sorted(se))