import time

def main():
	t = time.localtime()
	current_time = time.strftime("%H:%M:%S", t)
	print("Hora del sistema: ",current_time)

	hora = time.strftime("%H", t)

	if int(hora) >= 19:
		print("Es hora de ir a casa")
	else:
		res = 19 - int(hora)
		print("Quedan aproximadamente (hrs): ", res)


if __name__ == '__main__':
    main()


		

