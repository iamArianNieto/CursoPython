#crear archivo
archivo = open('8_1_Ejercisio.txt','x')
archivo.close()

#leer archivo
archivo = open('8_1_Ejercisio.txt','r')
datos = archivo.read()
archivo.close()
print(datos)

#escribir archivo
archivo = open('8_1_Ejercisio.txt','a')

lista = "Escrito desde archivo"


archivo.write(lista)
archivo.close()
datos = "Archivo Escrito"
print(datos)
